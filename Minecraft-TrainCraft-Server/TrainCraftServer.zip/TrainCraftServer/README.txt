1.) Copy all the files from config to C:/User/YOURNAME/Appdata/Roaming/.minecraft/config or to any other installation config folder.
2.) Copy the "Normal world" to saves folder
3.) Play the map

Credits: Map made by Spitfire4466